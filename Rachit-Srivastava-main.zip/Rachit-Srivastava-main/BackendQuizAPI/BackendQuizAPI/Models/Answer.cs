﻿namespace BackendQuizAPI.Models
{
    public class Answer
    {
        public string Response { get; set; }
    }
}
