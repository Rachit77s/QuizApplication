﻿namespace BackendQuizAPI.Models
{
    public class UserConstants
    {
        public static List<User> Users = new List<User>()
        {
            //new User() { Username = "jason_admin", Email = "jason.admin@email.com", Password = "MyPass_w0rd", GivenName = "Jason", Surname = "Bryant", Role = "Administrator" },
            //new User() { Username = "elyse_seller", EmailAddress = "elyse.seller@email.com", Password = "MyPass_w0rd", GivenName = "Elyse", Surname = "Lambert", Role = "Seller" },

            new User() { Email = "rachit77s@gmail.com", Password = "rachit", Role = "Admin" },
            new User() { Email = "jason.admin@gmail.com", Password = "MyPass_w0rd", Role = "Admin" },
            new User() { Email = "elyse.seller@gmail.com", Password = "MyPass_w0rd", Role = "User" },
        };
    }
}
