﻿using System.ComponentModel.DataAnnotations;

namespace BackendQuizAPI.Models
{
    public class PublishQuizModel
    {
        // public bool IsPublished { get; set; }
        [Key]
        public int Id { get; set; }
        public int QuizId { get; set; }
        public int UserId { get; set; }

        public string Permalink { get; set; }
    }
}
