﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BackendQuizAPI.DataAccessLayer;
using BackendQuizAPI.Models;
using BackendQuizAPI.Helpers;
using Microsoft.AspNetCore.Authorization;
using System.Data;
using System.Security.Claims;

namespace BackendQuizAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class QuizController : ControllerBase
    {
        private readonly QuizDbContext _context;

        public QuizController(QuizDbContext context)
        {
            _context = context;
        }

        // GET: api/Quiz
        //[HttpGet]
        //public async Task<ActionResult<IEnumerable<Quiz>>> GetQuizzes()
        //{
        //    return await _context.Quizzes.ToListAsync();
        //}

        // Get the info about the user
        private User GetCurrentUser()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;

            if (identity != null)
            {
                // It is IEnumerable i.e. a list
                var userClaims = identity.Claims;

                return new User
                {
                    Email = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Email)?.Value,
                    Role = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Role)?.Value
                    //Username = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.NameIdentifier)?.Value,
                    //GivenName = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.GivenName)?.Value,
                    //Surname = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Surname)?.Value,
                };
            }
            return null;
        }

        // GET: api/Quiz/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Quiz>> GetQuiz(int id)
        {
            //var user = GetCurrentUser();

            //var userDetails = await _context.Users.FindAsync(id);
            //if (userDetails == null)
            //{
            //    return NotFound("User not found");
            //}

            var quizDetails =  _context.Quizzes.Include(question => question.Questions).
                Where(x => x.UserId == id).FirstOrDefault();

            if (quizDetails == null)
            {
                return NotFound();
            }

            return quizDetails;
        }

        // PUT: api/Quiz/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("{id}")]
        //public async Task<IActionResult> PutQuiz(int id, Quiz quiz)
        //{
        //    if (id != quiz.QuizId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(quiz).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!QuizExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/Quiz
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Quiz>> PostQuiz(Quiz quiz)
        {
            try
            {
                if (quiz.UserId == 0)
                {
                    return BadRequest("Must provide UserId while creating the quiz.");
                }

                var checkQuizExists = _context.Quizzes.Where(x => x.UserId == quiz.UserId &&
                                      x.Title == quiz.Title).FirstOrDefault();

                if (checkQuizExists != null)
                {
                    Quiz newQuiz = new Quiz();
                    newQuiz.QuizId = quiz.QuizId;
                    newQuiz.UserId = quiz.UserId;
                    newQuiz.Title = quiz.Title;
                    newQuiz.Questions = quiz.Questions;

                    // _context.Quizzes.Add(newQuiz);
                    // _context.Entry(newQuiz).State = EntityState.Modified;

                    foreach (var item in quiz.Questions)
                    {
                        _context.Questions.Add(item);
                    }
                    
                    await _context.SaveChangesAsync();

                    return Ok(quiz.QuizId);
                }

                _context.Quizzes.Add(quiz);
                await _context.SaveChangesAsync();

                return Ok(quiz.QuizId);
            }
            catch (Exception ex)
            {
                // LogException(ex);
                // return StatusCode(500);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
            

            // return CreatedAtAction("GetQuiz", new { id = quiz.QuizId }, quiz);
        }

        [HttpPost]
        [Route("PublishQuiz")]
        public async Task<ActionResult<PublishQuizModel>> PublishQuiz(PublishQuizModel publishQuizModel)
        {
            if (publishQuizModel.QuizId == 0 || publishQuizModel.UserId == 0)
            {
                return BadRequest("Quiz does not exists.");
            }

            var quizDetails = _context.PublishQuizzes.Where(x => x.QuizId == publishQuizModel.QuizId &&
                                x.UserId == publishQuizModel.UserId).FirstOrDefault();

            if (quizDetails == null)
            { 
                if (publishQuizModel.Permalink.Equals("string") || 
                    String.IsNullOrWhiteSpace(publishQuizModel.Permalink))
                    publishQuizModel.Permalink = PermalinkGeneratorHelper.GeneratePermalink(6);

                _context.PublishQuizzes.Add(publishQuizModel);
                await _context.SaveChangesAsync();
            }
            else
            {
                return Ok("Permalink already exists!");
            }

            return Ok(publishQuizModel.Permalink);
        }

        [AllowAnonymous]
        [HttpGet]
        [Route("GetQuizByPermalink")]
        public async Task<ActionResult<Quiz>> GetQuizByPermalink(string link)
        {
            if (link == null || link.Equals("string"))
                return BadRequest("Pass valid Permalink!");

            try
            {
                var quizExists = _context.PublishQuizzes.Where(x => x.Permalink == link).FirstOrDefault();

                if (quizExists == null)
                {
                    return NotFound("Quiz does not exists for given Permalink!");
                }

                //var quizDetails = _context.Quizzes
                //            .Include(question => question.Questions)
                //            //    .ThenInclude(answer => answer.Answers)
                //            //.ThenInclude(author => author.Photo)
                //            .ToList();

                var quizDetails = _context.Quizzes.Include(question => question.Questions)
                                    .Where(x => x.QuizId == quizExists.QuizId).FirstOrDefault();

                return Ok(quizDetails);
            }
            catch (Exception ex)
            {
                return NotFound("Something went wrog " + ex);
            } 
        }

        // DELETE: api/Quiz/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteQuiz(int id)
        {
            var quiz = await _context.Quizzes.FindAsync(id);
            if (quiz == null)
            {
                return NotFound();
            }

            // _context.Quizzes.Remove(quiz);
            // await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool QuizExists(int id)
        {
            return _context.Quizzes.Any(e => e.QuizId == id);
        }
    }
}
