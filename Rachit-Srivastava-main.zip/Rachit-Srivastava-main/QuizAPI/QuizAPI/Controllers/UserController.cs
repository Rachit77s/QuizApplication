﻿//using AuthenticationAndAuthorizationWithJWT.Models;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Identity;
//using Microsoft.AspNetCore.Mvc;
//using QuizAPI.Models;
//using System.Data;
//using System.Security.Claims;

//// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

//namespace QuizAPI.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class UserController : ControllerBase
//    {
//        private readonly QuizDbContext _context;

//        public UserController(QuizDbContext context)
//        {
//            _context = context;
//        }

//        [HttpPost]
//        [Route("Registration")]
//        public async Task<ActionResult<User>> Registration(User user)
//        {
//            var temp = _context.Users
//               .Where(x => x.Email == user.Email
//                           && x.Password == user.Password)
//               .FirstOrDefault();

//            if (temp == null)
//            {
//                _context.Users.Add(user);
//                await _context.SaveChangesAsync();
//            }
//            else
//                user = temp;

//            return Ok(user);
//        }

//        [HttpPost]
//        [Route("Login")]
//        // public async Task<ActionResult<User>> Login(User user)
//        public async Task<ActionResult<User>> Login(User user)
//        {
//            var temp = _context.Users
//               .Where(x => x.Email == user.Email
//                           && x.Password == user.Password)
//               .FirstOrDefault();

//            if (temp == null)
//            {
//                return NotFound();
//            }

//            return Ok();
//            // return RedirectToAction(nameof(QuestionController.GetQuestions()), "Question");
//        }

//        //[HttpGet("Admins")]
//        //[Authorize(Roles = "Administrator")]
//        //public IActionResult AdminsEndpoint()
//        //{
//        //    var currentUser = GetCurrentUser();

//        //    return Ok($"Hi {currentUser.GivenName}, you are an {currentUser.Role}");
//        //}


//        //[HttpGet("Sellers")]
//        //[Authorize(Roles = "Seller")]
//        //public IActionResult SellersEndpoint()
//        //{
//        //    var currentUser = GetCurrentUser();

//        //    return Ok($"Hi {currentUser.GivenName}, you are a {currentUser.Role}");
//        //}

//        //[HttpGet("AdminsAndSellers")]
//        //[Authorize(Roles = "Administrator,Seller")]
//        //public IActionResult AdminsAndSellersEndpoint()
//        //{
//        //    var currentUser = GetCurrentUser();

//        //    return Ok($"Hi {currentUser.GivenName}, you are an {currentUser.Role}");
//        //}

//        //[HttpGet("Public")]
//        //public IActionResult Public()
//        //{
//        //    return Ok("Hi, you're on public property");
//        //}

//        // Get the info about the user
//        private UserModel GetCurrentUser()
//        {
//            var identity = HttpContext.User.Identity as ClaimsIdentity;

//            if (identity != null)
//            {
//                // It is IEnumerable i.e. a list
//                var userClaims = identity.Claims;

//                return new UserModel
//                {
//                    Username = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.NameIdentifier)?.Value,
//                    EmailAddress = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Email)?.Value,
//                    GivenName = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.GivenName)?.Value,
//                    Surname = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Surname)?.Value,
//                    Role = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Role)?.Value
//                };
//            }
//            return null;
//        }


//        // GET: api/<UserController>
//        //[HttpGet]
//        //public IEnumerable<string> Get()
//        //{
//        //    return new string[] { "value1", "value2" };
//        //}

//        //// GET api/<UserController>/5
//        //[HttpGet("{id}")]
//        //public string Get(int id)
//        //{
//        //    return "value";
//        //}

//        //// POST api/<UserController>
//        //[HttpPost]
//        //public void Post([FromBody] string value)
//        //{
//        //}

//        //// PUT api/<UserController>/5
//        //[HttpPut("{id}")]
//        //public void Put(int id, [FromBody] string value)
//        //{
//        //}

//        //// DELETE api/<UserController>/5
//        //[HttpDelete("{id}")]
//        //public void Delete(int id)
//        //{
//        //}
//    }
//}
