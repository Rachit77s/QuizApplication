﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuizAPI.Helper;
using QuizAPI.Models;
using System.Security.Claims;

namespace QuizAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class QuizController : ControllerBase
    {
        private readonly QuizDbContext _context;

        public QuizController(QuizDbContext context)
        {
            _context = context;
        }

        // GET: api/Quiz
        //[HttpGet]
        //public async Task<ActionResult<IEnumerable<Quiz>>> GetQuizzes()
        //{
        //    return await _context.Quizzes.ToListAsync();
        //}

        // Get the info about the user
        private User GetCurrentUser()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;

            if (identity != null)
            {
                // It is IEnumerable i.e. a list
                var userClaims = identity.Claims;

                return new User
                {
                    Email = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Email)?.Value,
                    Role = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Role)?.Value
                    //Username = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.NameIdentifier)?.Value,
                    //GivenName = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.GivenName)?.Value,
                    //Surname = userClaims.FirstOrDefault(o => o.Type == ClaimTypes.Surname)?.Value,
                };
            }
            return null;
        }

        // GET: api/Quiz/5
        [HttpGet("{userid}")]
        public async Task<ActionResult<IEnumerable<Quiz>>> GetQuiz(int userid)
        {
            var quizDetails = await _context.Quizzes.Include(question => question.Questions).
                Where(x => x.UserId == userid).ToListAsync();

            if (quizDetails == null)
            {
                return NotFound();
            }

            return quizDetails;
        }

        [HttpPost]
        [Route("SaveQuiz")]
        public async Task<ActionResult<Quiz>> CreateQuiz(Quiz quiz)
        {
            if (quiz.UserId == 0)
            {
                return BadRequest("Must provide UserId while creating the quiz.");
            }

            Quiz newQuiz = new Quiz();
            newQuiz.UserId = quiz.UserId;
            newQuiz.Title = quiz.Title;

            try
            {
                var checkQuizExists = _context.Quizzes.Where(x => x.UserId == quiz.UserId &&
                                      x.Title == quiz.Title).FirstOrDefault();

                // If not present, create the quiz
                if (checkQuizExists == null)
                {
                    _context.Quizzes.Add(newQuiz);
                    await _context.SaveChangesAsync();
                }
                else
                {
                    // return NotFound("Quiz not found. Please try again!");
                    newQuiz.QuizId = checkQuizExists.QuizId;
                    newQuiz.UserId = checkQuizExists.UserId;
                    newQuiz.Title = checkQuizExists.Title;
                }

                //var quizResult = await _context.Quizzes.FindAsync(newQuiz.QuizId);

                //if (quizResult != null)
                //{
                //    List<Question> listOfQuestions = new List<Question>();
                //    Question question = new Question();
                //    question.QuizId = newQuiz.QuizId;

                //    foreach (var item in quiz.Questions)
                //    {
                //        question.QnId = 0;
                //        question.QnInWords = item.QnInWords;
                //        question.Option1 = item.Option1;
                //        question.Option2 = item.Option2;
                //        question.Option3 = item.Option3;
                //        question.Option4 = item.Option4;
                //        question.Option5 = item.Option5;
                //        question.Answer = item.Answer;

                //        _context.Questions.Add(question);
                //        await _context.SaveChangesAsync();

                //        List<Answer> ans = new List<Answer>();
                //        Answer answer = new Answer();
                //        StringBuilder sb = new StringBuilder();

                //        for (int i = 0; i < item.Answers.Count; i++)
                //        {
                //            answer.QuestionQnId = question.QnId;
                //            sb.Append(item.Answers[i].Response);

                //            if (i == item.Answers.Count - 1)
                //                break;
                //            else
                //                sb.Append(",");
                //        }

                //        answer.Response = sb.ToString();

                //        _context.Answers.Add(answer);
                //        await _context.SaveChangesAsync();

                //        listOfQuestions.Add(question);
                //    }

                //    newQuiz.Questions = quiz.Questions;
                //}

                List<Question> listOfQuestions = new List<Question>();
                Question question = new Question();
                question.QuizId = newQuiz.QuizId;

                foreach (var item in quiz.Questions)
                {
                    question.QnId = 0;
                    question.QnInWords = item.QnInWords;
                    question.Option1 = item.Option1;
                    question.Option2 = item.Option2;
                    question.Option3 = item.Option3;
                    question.Option4 = item.Option4;
                    question.Option5 = item.Option5;
                    question.Answer = item.Answer;

                    // New added
                    question.AnswerResponse = item.AnswerResponse == null ? null : item.AnswerResponse;

                    _context.Questions.Add(question);
                    await _context.SaveChangesAsync();

                    //List<Answer> ans = new List<Answer>();
                    //Answer answer = new Answer();
                    //StringBuilder sb = new StringBuilder();

                    //for (int i = 0; i < item.Answers.Count; i++)
                    //{
                    //    answer.QuestionQnId = question.QnId;
                    //    sb.Append(item.Answers[i].Response);

                    //    if (i == item.Answers.Count - 1)
                    //        break;
                    //    else
                    //        sb.Append(",");
                    //}

                    //answer.Response = sb.ToString();

                    //_context.Answers.Add(answer);
                    //await _context.SaveChangesAsync();

                    listOfQuestions.Add(question);
                }

                newQuiz.Questions = quiz.Questions;

                return Ok(newQuiz.QuizId);
            }
            catch (Exception ex)
            {
                return NotFound("Something went wrong " + ex);
            }
        }

        [HttpPost]
        [Route("PublishQuiz")]
        public async Task<ActionResult<PublishQuizModel>> PublishQuiz(PublishQuizModel publishQuizModel)
        {
            if (publishQuizModel.QuizId == 0 || publishQuizModel.UserId == 0)
            {
                return BadRequest("Enter valid data!");
            }

            var quizDetails = _context.PublishQuizzes.Where(x => x.QuizId == publishQuizModel.QuizId &&
                                x.UserId == publishQuizModel.UserId).FirstOrDefault();

            if (quizDetails == null)
            {
                if (publishQuizModel.Permalink.Equals("string"))
                    publishQuizModel.Permalink = PermalinkGenerator.GeneratePermalink(6);

                _context.PublishQuizzes.Add(publishQuizModel);
                await _context.SaveChangesAsync();
            }
            else
            {
                return Ok("Permalink already exists!");
            }

            return Ok(publishQuizModel.Permalink);
        }

        [HttpGet]
        [Route("GetQuizByPermalink")]
        public async Task<ActionResult<Quiz>> GetQuizByPermalink(string link)
        {
            if (link == null || link.Equals("string"))
                return BadRequest("Pass valid Permalink!");

            try
            {
                var quizExists = _context.PublishQuizzes.Where(x => x.Permalink == link).FirstOrDefault();

                if (quizExists == null)
                {
                    return NotFound("Quiz does not exists!");
                }

                var quizDetails =  _context.Quizzes.Include(question => question.Questions)
                                    .Where(x => x.QuizId == quizExists.QuizId).FirstOrDefault();

                return Ok(quizDetails);
            }
            catch (Exception ex)
            {
                return NotFound("Something went wrong " + ex);
            }



            //var blogs = _context.Quizzes
            //            .Include(question => question.Questions)
            //                .ThenInclude(answer => answer.Answers)
            //                //.ThenInclude(author => author.Photo)
            //            .ToList();

            //var quiz = await _context.Quizzes.FindAsync(quizExists.QuizId);
            //var questions = await _context.Questions.Where(x => x.QuizId == quiz.QuizId).ToListAsync();

            //if (questions == null || questions.Count == 0)
            //    return NotFound();

            //for (int i = 0; i < questions.Count; i++)
            //{
            //    var answer = await _context.Answers.FindAsync(questions[i].QnId);
            //    //questions[i].AnswerResponse = 
            //}

            // TODO: Question should have a string as response
            // 
            //var answers = await _context.Answers.Where(x => x.QuestionQnId == questions.QnId).ToListAsync();

            //if (answers == null)
            //    return NotFound();

            //questions.AnswerResponse = answers;
            //quiz.Questions = questions;

            //return Ok(quiz);
        }

        // DELETE: api/Quiz/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteQuiz(int id)
        {
            var quiz = await _context.Quizzes.FindAsync(id);
            if (quiz == null)
            {
                return NotFound();
            }

            //_context.Entry(quiz).State = EntityState.Modified;
             //await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool QuizExists(int id)
        {
            return _context.Quizzes.Any(e => e.QuizId == id);
        }
    }
}
