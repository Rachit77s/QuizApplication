﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using NuGet.Packaging.Signing;
using QuizAPI.Helper;
using QuizAPI.Models;



namespace QuizAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuestionController : ControllerBase
    {
        private readonly QuizDbContext _context;

        public QuestionController(QuizDbContext context)
        {
            _context = context;
        }

        // GET: api/Question
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Question>>> GetQuestions()
        {
            var random5Qns = await (_context.Questions
                 .Select(x => new
                 {
                     QnId = x.QnId,
                     QnInWords = x.QnInWords,
                     ImageName = x.ImageName,
                     Options = new string[] { x.Option1, x.Option2, x.Option3, x.Option4, x.Option5 }
                 })
                 .OrderBy(y => Guid.NewGuid())
                 .Take(5)
                 ).ToListAsync();

            return Ok(random5Qns);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Question>> GetQuestion(int id)
        {
            var question = await _context.Questions.FindAsync(id);

            if (question == null)
            {
                return NotFound();
            }

            return question;
        }

        // PUT: api/Question/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("{id}")]
        //public async Task<IActionResult> PutQuestion(int id, Question question)
        //{
        //    if (id != question.QnId)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(question).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!QuestionExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        // POST: api/Question/GetAnswers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Route("GetAnswers")]
        public async Task<ActionResult<Question>> RetrieveAnswers(int[] qnIds)
        {
            var answers = await (_context.Questions
                .Where(x => qnIds.Contains(x.QnId))
                .Select(y => new
                {
                    QnId = y.QnId,
                    QnInWords = y.QnInWords,
                    ImageName = y.ImageName,
                    Options = new string[] { y.Option1, y.Option2, y.Option3, y.Option4, y.Option5 },
                    Answer = y.Answer,
                    AnswerResponse = y.AnswerResponse
                })).ToListAsync();

            return Ok(answers);
        }

        private bool QuestionExists(int id)
        {
            return _context.Questions.Any(e => e.QnId == id);
        }

        //[HttpPost]
        //[Route("GetAnswerPerQuestion")]
        //public async Task<ActionResult<Question>> GetAnswer(int qnId)
        //{
        //    //var answers = await (_context.Questions
        //    //    .Where(x => qnIds.Contains(x.QnId))
        //    //    .Select(y => new
        //    //    {
        //    //        QnId = y.QnId,
        //    //        QnInWords = y.QnInWords,
        //    //        ImageName = y.ImageName,
        //    //        Options = new string[] { y.Option1, y.Option2, y.Option3, y.Option4, y.Option5 },
        //    //        Answer = y.Answer,
        //    //        AnswerResponse = y.AnswerResponse
        //    //    })).ToListAsync();

        //    var answer =  (_context.Questions
        //       .Where(x => x.QnId == qnId)
        //       .Select(y => new
        //       {
        //           QnId = y.QnId,
        //           QnInWords = y.QnInWords,
        //           ImageName = y.ImageName,
        //           Options = new string[] { y.Option1, y.Option2, y.Option3, y.Option4, y.Option5 },
        //           Answer = y.Answer,
        //           AnswerResponse = y.AnswerResponse == null ? "" : y.AnswerResponse
        //       })).FirstOrDefault();

        //    if(answer.Answer == -1)
        //    {
        //        string[] str = answer.AnswerResponse.Split(",");

        //    }

        //    return Ok(answer);
        //}

        // DELETE: api/Question/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteQuestion(int id)
        //{
        //    var question = await _context.Questions.FindAsync(id);
        //    if (question == null)
        //    {
        //        return NotFound();
        //    }

        //    //_context.Questions.Remove(question);
        //    //await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        //[HttpPost]
        //[Route("CreateQuiz2")]
        //public async Task<ActionResult<Quiz>> CreateQuiz2(Quiz quizInput)
        //{
        //    var quizData = JsonConvert.DeserializeObject<Quiz>(quizInput.ToString());

        //    Quiz quiz = new Quiz();
        //    quiz.QuizId = quizData.QuizId;
        //    quiz.Title = quizData.Title;
        //    quiz.UserId = quizData.UserId;

        //    Question question = new Question();
        //    question.QuizId = quiz.QuizId;

        //    Answer answer = new Answer();
        //    StringBuilder sb = new StringBuilder();

        //    foreach (var item in quizInput.Questions)
        //    {
        //        question = item;

        //        foreach (var ansItem in item.Answers)
        //        {
        //            sb.Append(ansItem);
        //        }

        //        answer.Response = sb.ToString();
        //        _context.Answers.Add(answer);
        //        _context.Questions.Add(item);
        //    }

        //    // Add the quiz object to the database
        //    _context.Quizzes.Add(quiz);

        //    await _context.SaveChangesAsync();

        //    return quiz;
        //}

        //[HttpPost]
        //[Route("SaveQuiz")]
        //public async Task<ActionResult<Quiz>> CreateQuiz(Quiz quiz)
        //{
        //    if (quiz.UserId == 0)
        //    {
        //        return BadRequest("Must provide UserId while creating the quiz.");
        //    }

        //    Quiz newQuiz = new Quiz();
        //    newQuiz.UserId = quiz.UserId;
        //    newQuiz.Title = quiz.Title;

        //    try
        //    {
        //        var checkQuizExists = _context.Quizzes.Where(x => x.UserId == quiz.UserId &&
        //                              x.Title == quiz.Title).FirstOrDefault();

        //        // If not present, create the quiz
        //        if (checkQuizExists == null)
        //        {
        //            _context.Quizzes.Add(newQuiz);
        //            await _context.SaveChangesAsync();
        //        }
        //        else
        //        {
        //            newQuiz.QuizId = checkQuizExists.QuizId;
        //            newQuiz.UserId = checkQuizExists.UserId;
        //            newQuiz.Title = checkQuizExists.Title;
        //        }

        //        List<Question> listOfQuestions = new List<Question>();
        //        Question question = new Question();
        //        question.QuizId = newQuiz.QuizId;

        //        foreach (var item in quiz.Questions)
        //        {
        //            question.QnId = 0;
        //            question.QnInWords = item.QnInWords;
        //            question.Option1 = item.Option1;
        //            question.Option2 = item.Option2;
        //            question.Option3 = item.Option3;
        //            question.Option4 = item.Option4;
        //            question.Option5 = item.Option5;
        //            question.Answer = item.Answer;

        //            // New added
        //            question.AnswerResponse = item.AnswerResponse == null ? null : item.AnswerResponse;

        //            _context.Questions.Add(question);
        //            await _context.SaveChangesAsync();

        //            listOfQuestions.Add(question);
        //        }

        //        newQuiz.Questions = quiz.Questions;

        //        return Ok(newQuiz.QuizId);
        //    }
        //    catch (Exception ex)
        //    {
        //        return NotFound("Something went wrong " + ex);
        //    }
        //}



        //[HttpPost]
        //[Route("PublishQuiz")]
        //public async Task<ActionResult<PublishQuizModel>> PublishQuiz(PublishQuizModel publishQuizModel)
        //{
        //    if (publishQuizModel.QuizId == 0 || publishQuizModel.UserId == 0)
        //    {
        //        return BadRequest("Enter valid data!");
        //    }

        //    var quizDetails = _context.PublishQuizzes.Where(x => x.QuizId == publishQuizModel.QuizId && 
        //                        x.UserId == publishQuizModel.UserId).FirstOrDefault();

        //    if (quizDetails == null)
        //    {
        //        if (publishQuizModel.Permalink.Equals("string"))
        //            publishQuizModel.Permalink = PermalinkGenerator.GeneratePermalink(6);

        //        _context.PublishQuizzes.Add(publishQuizModel);
        //        await _context.SaveChangesAsync();
        //    }
        //    else
        //    {
        //        return Ok("Permalink already exists!");
        //    }

        //    return Ok(publishQuizModel.Permalink);
        //}

        //[HttpGet]
        //[Route("GetQuizByPermalink")]
        //public async Task<ActionResult<Quiz>> GetQuizByPermalink(string link)
        //{
        //    if (link == null || link.Equals("string"))
        //        return BadRequest("Pass valid Permalink!");

        //    try
        //    {
        //        var quizExists = _context.PublishQuizzes.Where(x => x.Permalink == link).FirstOrDefault();

        //        if (quizExists == null)
        //        {
        //            return NotFound("Quiz does not exists!");
        //        }

        //        var quizDetails = _context.Quizzes.Include(question => question.Questions)
        //                            .Where(x => x.QuizId == quizExists.QuizId).FirstOrDefault();

        //        return Ok(quizDetails);
        //    }
        //    catch (Exception ex)
        //    {
        //        return NotFound("Something went wrong " + ex);
        //    }



        //    //var blogs = _context.Quizzes
        //    //            .Include(question => question.Questions)
        //    //                .ThenInclude(answer => answer.Answers)
        //    //                //.ThenInclude(author => author.Photo)
        //    //            .ToList();

        //    //var quiz = await _context.Quizzes.FindAsync(quizExists.QuizId);
        //    //var questions = await _context.Questions.Where(x => x.QuizId == quiz.QuizId).ToListAsync();

        //    //if (questions == null || questions.Count == 0)
        //    //    return NotFound();

        //    //for (int i = 0; i < questions.Count; i++)
        //    //{
        //    //    var answer = await _context.Answers.FindAsync(questions[i].QnId);
        //    //    //questions[i].AnswerResponse = 
        //    //}

        //    // TODO: Question should have a string as response
        //    // 
        //    //var answers = await _context.Answers.Where(x => x.QuestionQnId == questions.QnId).ToListAsync();

        //    //if (answers == null)
        //    //    return NotFound();

        //    //questions.AnswerResponse = answers;
        //    //quiz.Questions = questions;

        //    //return Ok(quiz);
        //}

        //[HttpPost]
        //[Route("CreateQuiz2")]
        //public async Task<ActionResult<QuestionModel>> CreateQuiz2(UserQuizModel userQuizModel)
        //{
        //    Quiz newQuiz = new Quiz();
        //    newQuiz.UserId = userQuizModel.UserId;
        //    newQuiz.QuizId = 1;
        //    newQuiz.Title = userQuizModel.Title;

        //    foreach (var item in userQuizModel.Quiz)
        //    {
        //        newQuiz.Questions = item.Questions;
        //    }

        //    return Ok();
        //}


        //[HttpPost]
        //[Route("CreateQuestion")]
        //public async Task<ActionResult<QuestionModel>> CreateQuestion(QuestionModel question, Answer answer)
        //{
        //    //var answers = await (_context.Questions
        //    //    .Where(x => qnIds.Contains(x.QnId))
        //    //    .Select(y => new
        //    //    {
        //    //        QnId = y.QnId,
        //    //        QnInWords = y.QnInWords,
        //    //        ImageName = y.ImageName,
        //    //        Options = new string[] { y.Option1, y.Option2, y.Option3, y.Option4 },
        //    //        Answer = y.Answer
        //    //    })).ToListAsync();
        //    //return Ok(answers);

        //    QuestionModel quest = new QuestionModel();

        //    quest.QuestionId = 1;// QuestionCounter++;
        //    quest.QuestionText = "Temperature can be measured in?";
        //    quest.Option1 = "Kelvin";
        //    quest.Option2 = "Fahrenheit";
        //    quest.Option3 = "Grams";
        //    quest.Option4 = "Celsius";
        //    quest.Option5 = "Liters";

        //    List<Answer> answers = new List<Answer>
        //    {
        //        new Answer { Response = "Option1" },
        //        new Answer { Response = "Option2" },
        //        new Answer { Response = "Option4" },
        //    };

        //    question.Answers = answers;

        //    return Ok();
        //    //globalListOfQuestions.Add(question);
        //}
    }
}
