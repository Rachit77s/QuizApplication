﻿namespace QuizAPI.Models
{
    public class Answer
    {
        public int Id { get; set; }

        //public int QuestionQnId { get; set; }

        public string Response { get; set; }
    }
}
