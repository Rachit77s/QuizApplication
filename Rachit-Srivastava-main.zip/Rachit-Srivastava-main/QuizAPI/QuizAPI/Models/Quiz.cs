﻿using System.ComponentModel.DataAnnotations;

namespace QuizAPI.Models
{
    public class Quiz
    {
        [Key]
        public int QuizId { get; set; }
        public int UserId { get; set; }
        public string Title { get; set; }
        public List<Question> Questions { get; set; }
        public int IsActive { get; set; } = 1;
    }
}
