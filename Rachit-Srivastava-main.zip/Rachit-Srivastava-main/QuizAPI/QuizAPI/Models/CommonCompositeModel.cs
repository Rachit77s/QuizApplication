﻿//namespace QuizAPI.Models
//{
//    public class CommonCompositeModel
//    {
        
//        public class User
//        {
//            public int UserId { get; set; }
//            public Quiz Quiz { get; set; }
//        }

//        public class Quiz
//        {
//            public int QuizId { get; set; }
//            public int UserId { get; set; }
//            public string Title { get; set; }
//            public List<QuestionModel> Questions { get; set; }

//        }

//        public class PublishQuizModel
//        {
//            // public bool IsPublished { get; set; }
//            public int QuizId { get; set; }
//            public int UserId { get; set; }

//            public string Permalink { get; set; }
//        }

//        public class UserQuizModel
//        {
//            public int UserId { get; set; }
//            public string Title { get; set; }
//            public List<Quiz> Quiz { get; set; }
//        }


//        public class QuestionModel
//        {
//            public int QuestionId { get; set; }

//            public string QuestionText { get; set; }

//            public string Option1 { get; set; }

//            public string Option2 { get; set; }

//            public string Option3 { get; set; }

//            public string Option4 { get; set; }

//            public string Option5 { get; set; }

//            public List<Answer> Answers { get; set; }
//        }

//        public class Answer
//        {
//            public int AnswerId { get; set; }
//            public string Response { get; set; }
//        }
//    }
//}
