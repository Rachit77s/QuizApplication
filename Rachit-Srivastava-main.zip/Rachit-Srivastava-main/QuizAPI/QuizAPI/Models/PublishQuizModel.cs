﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace QuizAPI.Models
{
    public class PublishQuizModel
    {
        // public bool IsPublished { get; set; }
        [Key]
        public int Id { get; set; }
        public int QuizId { get; set; }
        public int UserId { get; set; }

        public string Permalink { get; set; }
    }
}
