﻿using Microsoft.Data.SqlClient;
using QuizAPI.Models;
using System.Data.Common;

namespace QuizAPI.DataAccessLayer
{
    public class AuthDL : IAuthDL
    {
        // public readonly IConfiguration _configuration;
        private readonly QuizDbContext _context;


        public AuthDL(QuizDbContext context)
        {
            // _configuration = configuration;
            _context = context;
        }

        public async Task<SignInResponse> SignIn(SignInRequest request)
        {
            SignInResponse response = new SignInResponse();
            response.IsSuccess = true;
            response.Message = "Successful";

            try
            {
                var temp = _context.Users
               .Where(x => x.Email == request.Email && x.Password == request.Password)
               .FirstOrDefault();

                if (temp == null)
                {
                    response.IsSuccess = false;
                    response.Message = "Login Unsuccessfull. User is invalid!";
                    return response;
                }

                response.Message = "Login Successfull";

                return response;
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<SignUpResponse> SignUp(SignUpRequest request)
        {
            SignUpResponse response = new SignUpResponse();
            response.IsSuccess = true;
            response.Message = "Successfull";

            try
            {
                var temp = _context.Users
                .Where(x => x.Email == request.Email && x.Password == request.Password)
                .FirstOrDefault();

               // var temp = _context.Users
               //.Where(x => x.Email == request.Email && x.Password == request.Password 
               //       && x.Role == request.Role)
               //.FirstOrDefault();

                if (temp == null)
                {
                    User user = new User();
                    user.Email = request.Email;
                    user.Password = request.Password;
                    user.Role = request.Role;
                    user.IsActive = 1;

                    _context.Users.Add(user);
                    await _context.SaveChangesAsync();
                }
                else
                {
                    response.Message = "User already exists!";
                    return response; ;
                }

                // return Ok(user);
                return response;
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Something Went Wrong " + ex.Message;
            }
            finally
            {

            }

            return response;
        }
    }
}
