import React, { useEffect } from 'react'
import { Button, Card, CardContent, TextField, Typography } from '@mui/material'
import { Box } from '@mui/system'
import Center from './Center'
import useForm from '../hooks/useForm'
import { createAPIEndpoint, ENDPOINTS } from '../api'
import useStateContext from '../hooks/useStateContext'
import { useNavigate } from 'react-router'
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import './BeautifyCode.css'
import AuthServices from '../services/AuthServices';
import Stack from '@mui/material/Stack';

const authService = new AuthServices();

const getFreshModel = () => ({
    name: '',
    email: '',
    password: '',
    radiovalue: 'Admin'
})

export default function SignUp() {

    
    const { context, setContext, resetContext } = useStateContext();
    const navigate = useNavigate()

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange
    } = useForm(getFreshModel);

    useEffect(() => {
        resetContext()
    }, [])

    const handleRadioChange = (e) => {

        var checked = e.target.checked
        // if(checked){
        //     this.setState({
        //         radiovalue: e.target.value
        //     })
        // }

        // setContext({ radiovalue: e.target.value })
        setValues({ radiovalue: e.target.value, email: values.email, password: values.password })
        // this.setState({ checked: e.target.checked })
      }


    // const login = e => {
    //     e.preventDefault();
    //     if (validate() )//&& validateUserCreds())
    //         createAPIEndpoint(ENDPOINTS.participant)
    //             .post(values)
    //             .then(res => {
    //                 setContext({ participantId: res.data.participantId })
    //                 navigate('/quiz')
    //             })
    //             .catch(err => console.log(err))
    // }


    // const validateUserCreds = () => {
    //     values.role = "Admin"
    //     createAPIEndpoint(ENDPOINTS.user)
    //       .post(values)
    //       .then(res => {
    //          console.log(res);
    //       })
    //       .catch(err => { console.log("User not found! " + "Error message: " + err) })
    //   }


    const validate = () => {
        
        // If all the values in temp is blank, it means that all the fields are valid and validation is successful
        let temp = {}
        temp.email = (/\S+@\S+\.\S+/).test(values.email) ? "" : "Email is not valid."
        // temp.name = values.name != "" ? "" : "This field is required."
        temp.password = values.password != "" ? "" : "This field is required."

        // If radio button is selected, set temp.radiovalue to the value of the selected radio button
        // if (values.radiovalue === 'Admin') {
        //     temp.radiovalue = 'Admin'
        // } else if (values.radiovalue === 'User') {
        //     temp.radiovalue = 'User'
        // }
        // else{
        //     temp.radiovalue = 'User'
        // }

        // temp.radiovalue = 'User'
        setErrors(temp)
        return Object.values(temp).every(x => x == "")
    }

    // This method is used for calling the backend API's of SignUp
    const submitToSignUpApi = (e) => {
        if (validate()) {

            // Call the API
            if (values.email !== '' && values.password !== '' ) {
                // This is request body
                const inputDataOfUser = {
                    email: values.email, password: values.password, role: values.radiovalue,
                } 

                // Call the Backend API by passing the request body to the AuthServices SignUp method
                authService.SignUp(inputDataOfUser)
                .then((inputDataOfUser) => {
                        console.log('data : ', inputDataOfUser)
                        // Check the response(data field) from the backend API
                        if (inputDataOfUser.data.isSuccess) {
                            // After successful sign up, redirect to SignIn page
                            navigate('/')
                        } else {
                            // If sign up fails, show the error message
                            console.log('Sign Up Failed')
                            setContext({ open: true, Message: 'Sign Up Failed' })
                        }
                    })
                .catch((error) => {
                        console.log('error : ', error)
                        setContext({ open: true, Message: 'Something Went Wrong' })
                })
            }
        }
        else{
            console.log("Validation failed!")
        }
    }

    // Rediect to SignIn/Login page
    const redirectToLogin = (e) => {
        navigate('/')
    }

    return (
        <Center>
            <Card sx={{ width: 400 }}>
                <CardContent sx={{ textAlign: 'center' }}>
                    <Typography variant="h3" sx={{ my: 3 }}>
                        Sign Up
                    </Typography>
                    <Box sx={{
                        '& .MuiTextField-root': {
                            m: 1,
                            width: '90%'
                        }
                    }}>
                        <form noValidate autoComplete="off" >
                            <TextField
                                label="Email"
                                name="email"
                                value={values.email}
                                onChange={handleInputChange}
                                variant="outlined"
                                {...(errors.email && { error: true, helperText: errors.email })} />
                            {/* <TextField
                                label="Name"
                                name="name"
                                value={values.name}
                                onChange={handleInputChange}
                                variant="outlined"
                                {...(errors.name && { error: true, helperText: errors.name })} /> */}
                             <TextField
                                label="Password"
                                name="password"
                                type="password"
                                value={values.password}
                                onChange={handleInputChange}
                                variant="outlined"
                                {...(errors.password && { error: true, helperText: errors.password })} />

                                <RadioGroup style={{ display: 'flex'}} className="Roles" name="Role" row value={values.radiovalue} onChange={handleRadioChange}>
                                    <FormControlLabel className="RoleValue" value="Admin" control={<Radio />} label="Admin" />
                                    <FormControlLabel className="RoleValue" value="User" control={<Radio />} label="User" />
                                    <FormControlLabel className="RoleValue" value="Guest" control={<Radio />} label="Guest" />
                                </RadioGroup>
                            {/* <Button
                                type="submit"
                                variant="contained"
                                size="large"
                                sx={{ width: '90%' }}>Start</Button> */}
                        </form>
                        {/* <div className="Buttons">
                            {/* <Button type="submit" variant="contained" size="large" sx={{ width: '90%' }}>Start</Button> */}
                            {/* <Button className="Btn" color="primary" onClick={this.handleSignIn}> Sign In </Button>
                            <Button className="Btn" color="primary" onClick={this.handleSubmit} variant="contained" > Sign Up </Button> */}
                            {/* <Button className="Btn" color="primary" variant="contained"  onClick={redirectToLogin}> Log In </Button>
                            <Button className="Btn" color="primary" variant="contained" onClick={submitToSignUpApi}> Sign Up </Button> */}
                        {/* </div> */} 

                        <Stack justifyContent="center" alignItems="center" spacing={2} direction="row" className="Buttons" >
                            <Button className="Btn" color="primary" variant="contained" onClick={redirectToLogin}>Log In</Button>
                            <Button className="Btn" color="primary" variant="contained" onClick={submitToSignUpApi}>Sign Up</Button>
                        </Stack>

                    </Box>
                </CardContent>
            </Card>
        </Center>


    )
}
