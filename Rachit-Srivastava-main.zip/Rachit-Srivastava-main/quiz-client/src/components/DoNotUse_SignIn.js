import React, { useEffect } from 'react'
import { Button, Card, CardContent, TextField, Typography } from '@mui/material'
import { Box } from '@mui/system'
import Center from './Center'
import useForm from '../hooks/useForm'
import { createAPIEndpoint, ENDPOINTS } from '../api'
import useStateContext from '../hooks/useStateContext'
import { useNavigate } from 'react-router'
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import './BeautifyCode.css'
import AuthServices from '../services/AuthServices';

const authService = new AuthServices();

const getFreshModel = () => ({
    email: '',
    password: '',
    radiovalue: 'Admin'
})

export default function SignIn() {

    const { context, setContext, resetContext } = useStateContext();
    const navigate = useNavigate()

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange
    } = useForm(getFreshModel);

    useEffect(() => {
        resetContext()
    }, [])

    const handleRadioChange = (e) => {
        this.setState({ Radiovalue: e.target.value })
      }


    const login = e => {
        e.preventDefault();
        if (validate() )//&& validateUserCreds())
            createAPIEndpoint(ENDPOINTS.participant)
                .post(values)
                .then(res => {
                    setContext({ participantId: res.data.participantId })
                    navigate('/quiz')
                })
                .catch(err => console.log(err))
    }

    const validate = () => {
        // If all the values in temp is blank, it means that all the fields are valid and validation is successful
        let temp = {}
        temp.email = (/\S+@\S+\.\S+/).test(values.email) ? "" : "Email is not valid."
        // temp.name = values.name != "" ? "" : "This field is required."
        temp.password = values.password != "" ? "" : "This field is required."

        // temp.radiovalue = 'User'
        setErrors(temp)
        return Object.values(temp).every(x => x == "")
    }

    // This method is used for calling the backend API's of SignUp
    const submitToLoginApi = (e) => {
        if (validate()) {

            // Call the API
            if (values.email !== '' && values.password !== '' ) {
                // This is request body
                const inputDataOfUser = {
                    email: values.email, password: values.password, role: values.radiovalue,
                } 

                // Call the Backend API by passing the request body to the AuthServices SignUp method
                authService.SignIn(inputDataOfUser)
                .then((inputDataOfUser) => {
                        console.log('data : ', inputDataOfUser)
                        // Check the response(data field) from the backend API
                        if (inputDataOfUser.data.isSuccess) {
                            // After successful sign up, redirect to SignIn page
                            navigate('/')
                        } else {
                            // If sign up fails, show the error message
                            console.log('LogIn Failed')
                            setContext({ open: true, Message: 'LogIn Failed' })
                        }
                    })
                .catch((error) => {
                        console.log('error : ', error)
                        setContext({ open: true, Message: 'Something Went Wrong' })
                })
            }
        }
        else{
            console.log("Validation failed!")
        }
    }

    // Redirect to SignIn/Login page
    const redirectToSignUp = (e) => {
        navigate('/signup')
    }

    return (
        <Center>
            <Card sx={{ width: 400 }}>
                <CardContent sx={{ textAlign: 'center' }}>
                    <Typography variant="h3" sx={{ my: 3 }}>
                        Login
                    </Typography>
                    <Box sx={{
                        '& .MuiTextField-root': {
                            m: 1,
                            width: '90%'
                        }
                    }}>
                        <form noValidate autoComplete="off" onSubmit={login}>
                            <TextField
                                label="Email"
                                name="email"
                                value={values.email}
                                onChange={handleInputChange}
                                variant="outlined"
                                {...(errors.email && { error: true, helperText: errors.email })} />
                             <TextField
                                label="Password"
                                name="password"
                                type="password"
                                value={values.password}
                                onChange={handleInputChange}
                                variant="outlined"
                                {...(errors.password && { error: true, helperText: errors.password })} />

                                <RadioGroup className="Roles" name="Role"  value={values.radiovalue} onChange={handleRadioChange}>
                                    <FormControlLabel className="RoleValue" value="Admin" control={<Radio />} label="Admin" />
                                    <FormControlLabel className="RoleValue" value="User" control={<Radio />} label="User" />
                                    <FormControlLabel className="RoleValue" value="Guest" control={<Radio />} label="Guest" />
                                </RadioGroup>
                            {/* <Button
                                type="submit"
                                variant="contained"
                                size="large"
                                sx={{ width: '90%' }}>Start</Button> */}
                        </form>
                        <div className="Buttons">
                            {/* <Button type="submit" variant="contained" size="large" sx={{ width: '90%' }}>Start</Button> */}
                            {/* <Button className="Btn" color="primary" onClick={this.handleSignIn}> Sign In </Button>
                            <Button className="Btn" color="primary" onClick={this.handleSubmit} variant="contained" > Sign Up </Button> */}
                            <Button className="Btn" color="primary" onClick={submitToLoginApi}> SignIn </Button>
                            <Button className="Btn" color="primary" variant="contained" onClick={redirectToSignUp}> Sign Up </Button>
                        </div>
                    </Box>
                </CardContent>
            </Card>
        </Center>


    )
}
