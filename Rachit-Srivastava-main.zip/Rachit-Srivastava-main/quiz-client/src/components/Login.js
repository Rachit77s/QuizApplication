import React, { useEffect } from 'react'
import { Button, Card, CardContent, TextField, Typography } from '@mui/material'
import { Box } from '@mui/system'
import Center from './Center'
import useForm from '../hooks/useForm'
import { createAPIEndpoint, ENDPOINTS } from '../api'
import useStateContext from '../hooks/useStateContext'
import { useNavigate } from 'react-router'
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import './BeautifyCode.css';
import AuthServices from '../services/AuthServices';
import Stack from '@mui/material/Stack';

const authService = new AuthServices();

const getFreshModel = () => ({
    // name: '',
    email: '',
    password: '',
    radiovalue: 'Admin'
})

export default function Login() {

    const { context, setContext, resetContext } = useStateContext();
    const navigate = useNavigate()

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange
    } = useForm(getFreshModel);

    useEffect(() => {
        resetContext()
    }, [])

    const handleRadioChange = (e) => {
        // setContext({ Radiovalue: e.target.value })
        setValues({ radiovalue: e.target.value })
      }


    // const login = e => {
    //     e.preventDefault();
    //     if (validate() )//&& validateUserCreds())
    //         createAPIEndpoint(ENDPOINTS.participant)
    //             .post(values)
    //             .then(res => {
    //                 setContext({ participantId: res.data.participantId })
    //                 navigate('/quiz')
    //             })
    //             .catch(err => console.log(err))
    // }

    // Redirect to SignIn/Login page
    const redirectToSignUp = (e) => {
        navigate('/signup')
    }

    
    const validate = () => {
        let temp = {}
        temp.email = (/\S+@\S+\.\S+/).test(values.email) ? "" : "Email is not valid."
        // temp.name = values.name != "" ? "" : "This field is required."
        temp.password = values.password != "" ? "" : "This field is required."
        // If radio button is selected, set temp.radiovalue to the value of the selected radio button
        // if (values.radiovalue === '') {
        //     temp.radiovalue = 'Admin'
        // } else if (values.radiovalue === 'User') {
        //     temp.radiovalue = 'User'
        // }
        // else{
        //     temp.radiovalue = 'User'
        // }

        setErrors(temp)
        return Object.values(temp).every(x => x == "")
    }

    const login = e => {
        e.preventDefault();
        if (validate() ) //&& validateUserCreds())
        {
            // Call the API
            if (values.email !== '' && values.password !== '' ) {
                // This is request body
                const inputDataOfUser = {
                    email: values.email, password: values.password, role: values.radiovalue,
                } 

                if (values.radiovalue === '') 
                    values.radiovalue = 'Admin'

                // Call the Backend API by passing the request body to the AuthServices SignUp method
                authService.SignIn(inputDataOfUser)
                .then((inputDataOfUser) => {
                        console.log('data : ', inputDataOfUser)
                        // Check the response(data field) from the backend API
                        if (inputDataOfUser.data.isSuccess) {
                            // After successful sign in, load quiz contents
                            createAPIEndpoint(ENDPOINTS.participant)
                                .post(values)
                                .then(res => {
                                    setContext({ participantId: res.data.participantId })
                                    navigate('/quiz')
                                })
                                .catch(err => console.log(err))
                        } else {
                            // If sign up fails, show the error message
                            console.log('LogIn Failed')
                            setContext({ open: true, Message: 'LogIn Failed' })
                        }
                    })
                .catch((error) => {
                        console.log('error : ', error)
                        setContext({ open: true, Message: 'Something Went Wrong' })
                })
            }
        }
    }



    return (
        <Center>
            <Card sx={{ width: 400 }}>
                <CardContent sx={{ textAlign: 'center' }}>
                    <Typography variant="h3" sx={{ my: 3 }}>
                        Signin Quiz App
                    </Typography>
                    <Box sx={{
                        '& .MuiTextField-root': {
                            m: 1,
                            width: '90%'
                        }
                    }}>
                        <form noValidate autoComplete="off" onSubmit={login}>
                            <TextField
                                label="Email"
                                name="email"
                                value={values.email}
                                onChange={handleInputChange}
                                variant="outlined"
                                {...(errors.email && { error: true, helperText: errors.email })} />
                            {/* <TextField
                                label="Name"
                                name="name"
                                value={values.name}
                                onChange={handleInputChange}
                                variant="outlined"
                                {...(errors.name && { error: true, helperText: errors.name })} /> */}
                             <TextField
                                label="Password"
                                name="password"
                                type="password"
                                value={values.password}
                                onChange={handleInputChange}
                                variant="outlined"
                                {...(errors.password && { error: true, helperText: errors.password })} />
                                <RadioGroup row  className="Roles" name="Role" value={values.radiovalue} onChange={handleRadioChange} >
                                    <FormControlLabel className="RoleValue" value="Admin" control={<Radio />} label="Admin" />
                                    <FormControlLabel className="RoleValue" value="User" control={<Radio />} label="User" />
                                    <FormControlLabel className="RoleValue" value="other" control={<Radio />} label="Other" />
                                </RadioGroup>
                            <Button type="submit" variant="contained" size="medium"  sx={{ width: '25%' }}> LogIn </Button>
                        </form>
                        <div> . </div>
                        {/* <div className="Buttons">
                               <Button className="Btn" color="primary" variant="contained" onClick={redirectToSignUp} sx={{ width: '40%' }}> Sign Up </Button>
                        </div> */}
                        <Stack justifyContent="center" alignItems="center" spacing={2} direction="row" className="Buttons" >
                            <Button className="Btn" color="primary" variant="contained" onClick={redirectToSignUp}>Sign Up</Button>
                        </Stack>
                    </Box>
                </CardContent>
            </Card>
        </Center>
    )
}
