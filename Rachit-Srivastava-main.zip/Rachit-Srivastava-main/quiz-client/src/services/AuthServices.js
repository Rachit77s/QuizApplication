import AxiosServices from './AxiosServices'
import Configurations from '../configurations/Configurations'

const axiosServices = new AxiosServices()

// What all API's would be call on backend, we will create function for all of them.
export default class AuthServices {

// Pass data from SignUp.js class to this function
  SignUp(data) {
    // Post data to backend, check post syntax in AxiosServices.js class
    return axiosServices.post(Configurations.SignUp, data, false)
  }

  SignIn(data) {
    return axiosServices.post(Configurations.SignIn, data, false)
  }
}