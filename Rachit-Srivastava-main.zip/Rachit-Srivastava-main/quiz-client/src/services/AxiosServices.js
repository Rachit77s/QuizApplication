const axios = require('axios').default

// Axios is used to call the API in backend
export default class AxiosServices {

    // IsRequired will tell us if we are going to use authentication or not
    // Header will tell us if the token is getting passed or not
  post(url, data, isRequiredHeader = false, header) {
    return axios.post(url, data, isRequiredHeader && header)
  }

}