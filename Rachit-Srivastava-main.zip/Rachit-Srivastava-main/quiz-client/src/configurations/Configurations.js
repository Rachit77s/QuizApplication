module.exports = {
    // SignUp: 'https://localhost:44381/api/Auth/SignUp',
    // SignIn: 'https://localhost:44381/api/Auth/SignIn',

    SignUp: 'http://localhost:5041/api/Auth/SignUp',
    SignIn: 'http://localhost:5041/api/Auth/SignIn',
  }

  // http://localhost:5041/swagger/index.html

  // Will hold URL's for all API's of the backend